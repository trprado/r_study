# lzw
LZW en- and decoding
